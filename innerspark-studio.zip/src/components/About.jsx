export default function About() {
  return (
    <section id="about" className="py-16 px-6 md:px-16 bg-lightBeige">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-4">Welcome</h2>
        <p className="text-lg leading-relaxed">
          At InnerSpark Studio, we believe every child carries a tiny spark of creativity, curiosity, and wonder.
          Our mission is to ignite these sparks through education, creativity, and emotional growth —
          shaping confident and joyful learners. Through storytelling, playful exploration, and meaningful
          learning experiences, we light up each child’s path with connection, imagination, and heart.
          <br /><br />
          We believe that nurturing a child's mind and heart can light up their whole future.
          <br /><br />
          Join us on this magical journey of learning and dreaming together!
        </p>
      </div>
    </section>
  )
}