export default function Contact() {
  return (
    <section id="contact" className="py-16 px-6 md:px-16 bg-lightPurple text-center">
      <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
      <p className="text-lg mb-6">We'd love to hear from you! Email us at:</p>
      <a href="mailto:hello@innersparkstudio.com" className="text-xl text-blue-900 font-semibold hover:underline">
        hello@innersparkstudio.com
      </a>
    </section>
  )
}