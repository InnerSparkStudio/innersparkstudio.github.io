export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center bg-lightPurple text-center px-4">
      <h1 className="text-4xl md:text-6xl font-bold mb-4">InnerSpark Studio</h1>
      <p className="text-xl italic mb-6">Where little sparks of magic are born...</p>
      <a href="#about" className="bg-lightYellow text-gray-900 px-6 py-2 rounded-full text-lg font-medium hover:bg-yellow-200 transition">
        Discover More
      </a>
    </section>
  )
}