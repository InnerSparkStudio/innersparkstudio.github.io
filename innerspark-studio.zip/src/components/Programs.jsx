export default function Programs() {
  return (
    <section id="programs" className="py-16 px-6 md:px-16 bg-lightYellow">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-8">Our Programs</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="font-semibold text-xl mb-2">Storytelling Adventures</h3>
            <p>Interactive tales that spark imagination and build literacy with heart.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="font-semibold text-xl mb-2">Creative Workshops</h3>
            <p>Hands-on sessions exploring art, play, music, and emotional expression.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="font-semibold text-xl mb-2">Mindful Learning</h3>
            <p>Gentle practices that support focus, empathy, and inner growth.</p>
          </div>
        </div>
      </div>
    </section>
  )
}