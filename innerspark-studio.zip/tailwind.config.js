/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        lightPurple: "#D9CFF0",
        lightYellow: "#FFF7CC",
        lightBeige: "#FAF3E0",
      },
    },
  },
  plugins: [],
}